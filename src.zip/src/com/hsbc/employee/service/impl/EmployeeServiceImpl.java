package com.hsbc.employee.service.impl;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.dao.EmployeeDao;
import com.hsbc.employee.dao.impl.EmployeeDaoImpl;
import com.hsbc.employee.dao.impl.EmployeeDaoImplDB;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;
import com.hsbc.employee.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService{
	//EmployeeDao dao = new EmployeeDaoImpl();
	EmployeeDao dao = new EmployeeDaoImplDB();
	@Override
	public int addEmployee(Employee emp) throws EmployeeAlreadyExistsException {
		return dao.addEmployee(emp); 
	}

}
