package com.hsbc.employee.service;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;

public interface EmployeeService {
	int addEmployee(Employee emp) throws EmployeeAlreadyExistsException;
}
 