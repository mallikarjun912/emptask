package com.hsbc.employee.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;
import com.hsbc.employee.service.EmployeeService;
import com.hsbc.employee.service.impl.EmployeeServiceImpl;

public class EmployeeApplication {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmployeeService service = new EmployeeServiceImpl();
		// UI
		int choice=0;
		while(choice!=5) {
			System.out.println("1. Add Employee");
			System.out.println("2. Search Employee");
			System.out.println("3. Sort Employee");
			System.out.println("4. Display ALL Employee2");
			System.out.println("5. Exit");
			System.out.println("Enter choice ");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
			{
				System.out.println("Enter code name, salary doj");
				int code = sc.nextInt();
				String name = sc.next();
				double salary = sc.nextDouble();
				String doj = sc.next();
				LocalDate datejoin = LocalDate.parse(doj, 
						DateTimeFormatter.ISO_DATE);
				Employee emp = new Employee();
				emp.setCode(code);
				emp.setName(name);
				emp.setSalary(salary);
				emp.setDoj(datejoin);
				try {
					int rows=service.addEmployee(emp);
					if(rows>0)
						System.out.println("inserted");
					else
						System.out.println("not-inserted");
				} catch (EmployeeAlreadyExistsException e) {
					e.printStackTrace();
				}
				break;
				}
			}
		}
		System.out.println("completed");  
		sc.close();
	}
}
