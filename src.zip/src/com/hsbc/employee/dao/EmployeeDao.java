package com.hsbc.employee.dao;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;

public interface EmployeeDao {
	int addEmployee(Employee emp) throws EmployeeAlreadyExistsException;
}
