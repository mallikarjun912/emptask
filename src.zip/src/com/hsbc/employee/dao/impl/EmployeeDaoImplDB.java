package com.hsbc.employee.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.dao.EmployeeDao;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;
import com.hsbc.employee.utils.DBConnection;

public class EmployeeDaoImplDB implements EmployeeDao{
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	
	@Override
	public int addEmployee(Employee emp) throws EmployeeAlreadyExistsException {
		String addqry = "insert into employee values(?,?,?,?)";
		int rows=0;
		conn = DBConnection.getConnection();
		try {
			pst = conn.prepareStatement(addqry);
			pst.setInt(1, emp.getCode());
			pst.setString(2, emp.getName());
			pst.setDouble(3, emp.getSalary());
			pst.setString(4, emp.getDoj().toString()); 
			rows = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBConnection.close();
		return rows;
	}

}
