package java11features;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FileMethods {
	public static void main(String[] args) {
	try {
			Path path = Files.createTempFile("tempfile", ".txt");
			Files.writeString(path, "Hello NIO");
			String str = Files.readString(path);
			System.out.println(str);
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
