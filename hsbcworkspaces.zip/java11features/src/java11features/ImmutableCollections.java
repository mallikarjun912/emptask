package java11features;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ImmutableCollections {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("hyd");
		list.add("bang");
		list.add("chen");
		System.out.println(list);
		//Immutable List
		List<String> imlist = Collections.unmodifiableList(list);
		System.out.println(imlist); 
		List<String> imlist2 = List.of("jan","feb","mar");
		//imlist2.add("apr");
		System.out.println(imlist2);  
		Set<String> set = Set.of("one","two","three");
		System.out.println(set);  
		Map<String, String> map = Map.of("TS","Telangana","AP","Andhra Pradesh");
		System.out.println(map);  
		map.forEach((k,v)->System.out.println(k+" : "+v));  
	}

}
