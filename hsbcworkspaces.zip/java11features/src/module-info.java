/**
 * 
 */
/**
 * @author malli
 *
 */
module java11features {
}