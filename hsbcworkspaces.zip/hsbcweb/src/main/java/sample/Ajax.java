package sample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ajax
 */
@WebServlet("/Ajax")
public class Ajax extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		String a[] = {"Arya","anil","anand","Abc","Balu","boy","Dog","Elephant","mysql","spring","Spring boot",
				"java","hsbc","johnson","james","mlk","jailer"};
		String s = request.getParameter("str");
		//out.println(s);
		String hint="";
		if(s!=null)
		{
			for(int i=0;i<a.length;i++)
				if(a[i].toUpperCase().startsWith(s.toUpperCase()))
						hint = hint+a[i]+" " ;
		}
		else
			hint=" ";
		
		if(hint==null || hint.length()==0)
			response.getWriter().write("No suggestions");
		else
			//response.getWriter().write(hint);
			out.print(hint);
	}

}
