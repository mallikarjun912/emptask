package sample;

public class Student {
	private int rno;
	private String stdname;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(int rno, String stdname) {
		this.rno = rno;
		this.stdname = stdname;
	}

	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	
}
