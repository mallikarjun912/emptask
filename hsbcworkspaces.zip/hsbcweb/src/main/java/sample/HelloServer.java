package sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class HelloServer
 */
@WebServlet("/HelloServer")
public class HelloServer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.setContentType("text/html");
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8"); 
		PrintWriter out = response.getWriter();
		//out.println("welcome to server");
		//out.println("<h1>welcome to server</h1>");
		JsonObject json = new JsonObject();
		json.addProperty("empcode", 101);
		json.addProperty("empname", "james gosling");
		//out.println(json.toString()); 
		out.println(json); 
		Student std = new Student();
		std.setRno(3333);
		std.setStdname("hsbc");
		Gson gson = new Gson();
		String student = gson.toJson(std);
		out.println(student);
		List<Student> stdlist = new ArrayList<>();
		stdlist.add(new Student(101, "aaaa"));
		stdlist.add(new Student(121, "bbbb"));
		stdlist.add(new Student(301, "cccc"));
		String list = gson.toJson(stdlist);
		out.println(list); 
	}

}
