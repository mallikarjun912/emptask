package com.hsbc.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;
import com.hsbc.employee.service.EmployeeService;
import com.hsbc.employee.service.impl.EmployeeServiceImpl;

/**
 * Servlet implementation class AddEmployee
 */
@WebServlet("/AddEmployee")
public class AddEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		EmployeeService service = new EmployeeServiceImpl("database");
		int code = Integer.parseInt(request.getParameter("empcode"));
		String name = request.getParameter("empname");
		double sal = Double.parseDouble(request.getParameter("salary"));
		String doj = request.getParameter("doj");
		LocalDate datejoin = LocalDate.parse(doj, 
				DateTimeFormatter.ISO_DATE);
		Employee emp = new Employee();
		emp.setCode(code);
		emp.setName(name);
		emp.setSalary(sal);
		emp.setDoj(datejoin); 
		try {
			int rows=service.addEmployee(emp);
			if(rows>0)
				out.println("inserted");
			else
				out.println("not-inserted");
		} catch (EmployeeAlreadyExistsException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
