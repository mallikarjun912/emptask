package com.hsbc.employee.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.dao.EmployeeDao;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;
import com.hsbc.employee.utils.DBConnection;

public class EmployeeDaoImplDB implements EmployeeDao{
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	
	@Override
	public int addEmployee(Employee emp) throws EmployeeAlreadyExistsException {
		String addqry = "insert into employee values(?,?,?,?)";
		String search = "select code from employee where code=?";
		int rows=0;
		conn = DBConnection.getConnection();
		try {
			pst = conn.prepareStatement(search);
			pst.setInt(1, emp.getCode()); 
			rs = pst.executeQuery();
			if(rs.next())
				throw new EmployeeAlreadyExistsException();
			pst = conn.prepareStatement(addqry);
			pst.setInt(1, emp.getCode());
			pst.setString(2, emp.getName());
			pst.setDouble(3, emp.getSalary());
			pst.setString(4, emp.getDoj().toString()); 
			rows = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBConnection.close();
		return rows;
	}

	@Override
	public int updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteEmployee(int code) {
		String delqry = "delete from employee where code=?";
		int rows=0;
		conn = DBConnection.getConnection();
		try {
			conn.setAutoCommit(false); 
			pst = conn.prepareStatement(delqry);
			pst.setInt(1, code); 
			rows = pst.executeUpdate();
			//conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBConnection.close();
		return rows;
	}

	@Override
	public List<Employee> findAll() {
		String selectqry = "select * from employee";
		List<Employee> emplist = new ArrayList<>();
		conn = DBConnection.getConnection();
		try {
			pst = conn.prepareStatement(selectqry);
			rs = pst.executeQuery();
			while(rs.next()) {
				Employee emp = new Employee();
				emp.setCode(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setSalary(rs.getDouble(3));
				String doj = rs.getDate(4).toString();
				LocalDate date = LocalDate.parse(doj,DateTimeFormatter.ISO_DATE);
				emp.setDoj(date);
				emplist.add(emp);
			}
		} catch (SQLException e) {
				e.printStackTrace();
		}
		return emplist;
	}

	@Override
	public Employee findByCode(int code) {
		// TODO Auto-generated method stub
		return null;
	}

}
