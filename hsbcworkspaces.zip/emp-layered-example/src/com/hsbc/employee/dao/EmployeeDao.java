package com.hsbc.employee.dao;

import java.util.List;

import com.hsbc.employee.beans.Employee;
import com.hsbc.employee.exceptions.EmployeeAlreadyExistsException;

public interface EmployeeDao {
	int addEmployee(Employee emp) throws EmployeeAlreadyExistsException;
	int updateEmployee(Employee emp);
	int deleteEmployee(int code);
	List<Employee> findAll();
	Employee findByCode(int code);
}
