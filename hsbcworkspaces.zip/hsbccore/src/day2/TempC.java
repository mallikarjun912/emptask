package day2;

public class TempC {
	int x;
	public TempC(int x) {
		this.x = x;
	}
	public TempC() {
		this(10);
		System.out.println("x = "+x);  
	}
	public static void main(String[] args) {
		TempC c = new TempC();
	}

}
