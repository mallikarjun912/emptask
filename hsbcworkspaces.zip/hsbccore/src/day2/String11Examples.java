package day2;

public class String11Examples {
	public static void main(String[] args) {
		String str = "java is very simple language";
	
	}
}
