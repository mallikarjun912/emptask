package day2;

import java.util.Scanner;

public class StudentApplication {
	void inputData(Student[] std) {
		Scanner sc = new Scanner(System.in); 
		for(int i=0;i<std.length;i++) {
			System.out.println("Enter regno name branch sub1 sub2 sub3");
			std[i] = new Student();
			std[i].setRegno(sc.nextInt());
			std[i].setName(sc.next()); 
			std[i].setBranch(sc.next());
			std[i].setSub1(sc.nextInt());
			std[i].setSub2(sc.nextInt());
			std[i].setSub3(sc.nextInt());
		}
		sc.close();
	}
	void findResult(Student[] std) {
		int total;
		double avg;
		String grade;
		for(int i=0;i<std.length;i++) {
			total = std[i].getSub1()+std[i].getSub2()+std[i].getSub3();
			avg = total/3;
			if(std[i].getSub1()>=40 && std[i].getSub2()>=40 && 
					std[i].getSub3()>=40) {
				if(avg>=60)
					grade= "First";
				else if(avg>=50)
					grade = "Second";
				else
					grade = "Third";
			}
			else
				grade = "Fail";
			
			System.out.println(std[i].getName()+" "+total+" "+avg+" "+grade);
 		}
	}
	public static void main(String[] args) {
		Student[] students = new Student[3];
		StudentApplication app = new StudentApplication();
		app.inputData(students);
		app.findResult(students); 
	}
}
