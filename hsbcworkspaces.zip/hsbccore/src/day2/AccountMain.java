package day2;

public class AccountMain {
	void display(Account acn) {
		System.out.println(acn.getAcno()+acn.getName()+acn.getBalance());
	}
	void show(Account[] a) {
		for(Account an : a)
			System.out.println(an.getAcno()); 
	}
	Account[] arrShow(Account[] ac) {
		for(Account a : ac) {
			a.setBalance(5000); 
		}
		return ac;
	}
	public static void main(String[] args) {
		Account acn = new Account(11,"aaa",6000);
		Account acn2 = new Account(22,"bbb",8000);
		Account acn23 = new Account();
		Account a[] = new Account[3];
				
		AccountMain main = new AccountMain();
		main.display(acn); 
		
		for(int i=0;i<3;i++) {
			a[i] = new Account();
			a[i].setAcno(10+i); 
		}
		main.show(a); 
		Account[] n = main.arrShow(a);
		System.out.println("from main");
		for(Account t : n)
			System.out.println(t.getAcno()+" "+t.getBalance());  
	
		for(Account c : a)
			System.out.println(c.getAcno()+" "+c.getBalance());  
	}
}
