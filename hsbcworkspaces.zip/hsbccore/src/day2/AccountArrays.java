package day2;

public class AccountArrays {
	void add(int x,int y) {
		System.out.println("add=  "+(x+y));
	}
	void displayObject(Account acnt) {
		acnt.setBalance(90000); 
		System.out.println("from displayObject method");
		System.out.println(acnt.getAcno()+acnt.getName()+acnt.getBalance());
	}
	void showArray(Account[] acnts) {
		System.out.println("object arrays passing as parameter");
		for(int i=0;i<acnts.length;i++)
			System.out.println(acnts[i].getAcno()+" "+acnts[i].getName());
	}
	public static void main(String[] args) {
		Account acn[] = new Account[3];
		for(int i=0;i<3;i++) {
			acn[i] = new Account();
			acn[i].setAcno(100+i); 
			System.out.println(acn[i].getAcno()+" "+acn[i].getBalance()); 
		}
		AccountArrays aa = new AccountArrays();
		aa.add(4, 10);
		Account ac = new Account();
		System.out.println(ac.getBalance()); 
		aa.displayObject(ac); 
		System.out.println(ac.getBalance()); 
		aa.showArray(acn); 
	}
}
