package day2;

public class Arithmetic {
	void add(int x,int y) {
		System.out.println("int = "+(x+y));
	}
	void add(double x,double y) {
		System.out.println("double = "+(x+y));
	}
	void add(String x, String y) {
		System.out.println("string = "+(x+y)); 
	}
	public static void main(String[] args) {
		Arithmetic arth = new Arithmetic();
		arth.add(10.5, 20.3); 
		arth.add("aaa", "bbb");
	}
}
