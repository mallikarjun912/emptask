package day3;

public abstract class First {
	protected int x;
	protected int y;
	public First() {
		x=10;
		y=20;
	}
	public abstract void display(); 
}
