package day3;

public class Library extends Student{
	private int booksTaken;
	public Library() {
		// TODO Auto-generated constructor stub
	}
	public Library(int regno, String name, String branch, int booksTaken) {
		super(regno,name,branch);
		this.booksTaken = booksTaken;
	}
	public void display() {
		System.out.println("from Library sub class");
	}
	public void showBooksInfo() {
		System.out.println(regno+name+branch+booksTaken); 
	}
	public static void main(String[] args) {
		Library lib = new Library(111,"hsbc","ECE",6); 
		lib.showBooksInfo();
		
		Student std = new Student();
		std.display();
		std = new Library(); //implicit object casting
		std.display();
		
		Library sub = new Library();
		sub.display();
		sub.showBooksInfo();
		sub = (Library) new Student();//explicit object casting
	}
}
