package day3;

public interface One {
	void methodOne();
}
