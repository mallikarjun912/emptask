package day3;

public class TestAbstract extends First{
	
	public static void main(String[] args) {
		TestAbstract test = new TestAbstract();
		test.display();
	}

	@Override
	public void display() {
		System.out.println("this abstract method");		
	}

}
