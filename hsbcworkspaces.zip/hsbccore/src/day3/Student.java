package day3;

public class Student {
	protected int regno;
	protected String name;
	protected String branch;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public Student(int regno, String name, String branch) {
		this.regno = regno;
		this.name = name;
		this.branch = branch;
	}
	
	public void display() {
		System.out.println("from Student super class");  
	}
	
}
