package day3;

public class CurrentAccount extends Account{
	protected double overDraftLimit;
	
	public CurrentAccount(String name, double balance,String accountType) {
		super(name, balance,accountType);
	}
	
	public void createAccount() {
		if(balance<50000)
			System.out.println(accountType+" Account cannot be created as min balance is less than 50000");
		else {
			acno=1110011;
			overDraftLimit = 500000;
			System.out.println("account no : "+acno);
			System.out.println("Name : "+name);
			System.out.println("Opening bal : "+balance);
			System.out.println("Account Type : "+accountType);
			System.out.println("Over Draft Limit : "+overDraftLimit);
		}
	}
}
