package day3;

public class TestInterfaces implements One,Two{

	public static void main(String[] args) {
		TestInterfaces test = new TestInterfaces();
		test.methodOne();
		test.methodTwo();
	}

	@Override
	public void methodOne() {
		System.out.println("from methodOne()");		
	}

	@Override
	public void methodTwo() {
		System.out.println("from methodTwo()");				
	}

}
