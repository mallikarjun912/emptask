package day3;

public class SavingsAccount extends Account{
	protected double interestRate;

	public SavingsAccount(String name, double balance, String accountType) {
		super(name, balance,accountType);
	}
	public void createAccount() {
		if(balance<10000)
			System.out.println(accountType+" Account cannot be created as min balance is less than 10000");
		else {
			acno=1110011;
			interestRate = 4.5;
			System.out.println("account no : "+acno);
			System.out.println("Name : "+name);
			System.out.println("Opening bal : "+balance);
			System.out.println("Account Type : "+accountType);
			System.out.println("Interest : "+interestRate);
		}
	}
	
}
