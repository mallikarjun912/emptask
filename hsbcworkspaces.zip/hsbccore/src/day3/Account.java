package day3;

public class Account {
	protected int acno;
	protected String name;
	protected double balance;
	protected String accountType;
    final double PI=3.14;	
	public Account(String name, double balance, String accountType) {
		this.name = name;
		this.balance = balance;
		this.accountType = accountType;
	}
	public void createAccount() {
		
	}
}
