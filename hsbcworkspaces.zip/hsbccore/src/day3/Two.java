package day3;

public interface Two {
	void methodTwo();
}
