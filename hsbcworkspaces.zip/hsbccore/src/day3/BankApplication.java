package day3;

public class BankApplication {
	public static void main(String[] args) {
		String name = "Hsbc";
		double bal = 25000;
		String type = "current";
		if(type.equals("savings")) {
			SavingsAccount sa = new SavingsAccount(name,bal,type);
			sa.createAccount();
		}
		else {
			CurrentAccount ca = new CurrentAccount(name,bal,type);
			ca.createAccount();
		}
	}
}
