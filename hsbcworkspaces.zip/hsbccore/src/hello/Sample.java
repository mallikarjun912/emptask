package hello;

import day4.TestStatic;

public class Sample {

	public static void main(String[] args) {
		int a = TestStatic.x;
		System.out.println("a = "+a);  
	}

}
