package hsbccore;

public class StringMethods {
	public static void main(String[] args) {
		String str = "hyderabad";
		String str2 = "bangalore";
		System.out.println("length = "+str.length()); 
		System.out.println("charAt = "+str.charAt(2));  
		System.out.println("sub-string = "+str.substring(4)); 
		System.out.println("sub-string = "+str.substring(4,7));
		System.out.println("equals = "+str.equals(str2));  
		System.out.println("compareTo = "+str.compareTo(str2));  

	}
}
