package hsbccore;

public class MutableStrings {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		sb.append("hsbc");
		sb.append("hyd");
		System.out.println(sb); 
		sb.delete(3, 5);
		System.out.println(sb);  
		StringBuffer sb1 = new StringBuffer("hyderabad");
		sb1.reverse();
		System.out.println(sb1);  
		//Write a java program to check for a Palindrome string
		//Write a java program to print every word on separate line
		// from the given string: java is a simple programmming language
		String st = "i am good";
		String st2[] = st.split(" ");
		for(String s : st2)
			System.out.println(s); 
	}
}
