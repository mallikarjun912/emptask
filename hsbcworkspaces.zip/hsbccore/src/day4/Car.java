package day4;

public class Car {
	Wheels wheels;
	public void setWheels(Wheels wheels) {
		this.wheels = wheels;
	}
	public Wheels getWheels() {
		return wheels;
	}
}
