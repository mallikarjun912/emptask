package day4;

public class TestStatic {
	public static int x=10;
	void display() {
		System.out.println("x = "+x);  
	}
	public static void main(String[] args) {
		x++;
	}

}
