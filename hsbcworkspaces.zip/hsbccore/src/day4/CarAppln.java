package day4;

public class CarAppln {
	public static void main(String[] args) {
		//Car car = new Car();
	//	car.setWheels(new Ceat()); 
		//car.getWheels().rotate();
		
		
		WheelsFactory factory = new WheelsFactory();
		Wheels whls = factory.getWheels("mrf");
		whls.rotate();
	}
}
