package day4;

public class Ceat implements Wheels{
	@Override
	public void rotate() {
		System.out.println("Car is moving with CEAT wheels");
	}
}
