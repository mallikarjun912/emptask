package day4;

public class WheelsFactory {
	public Wheels getWheels(String vendor) {
		switch(vendor) {
		case "mrf":
			return new Mrf();
		case "ceat" :
			return new Ceat();
			default :
				return null;
		}
	}
}
