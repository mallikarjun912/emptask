package day4.layered;

public class StudentNotFoundException extends Exception{
	public StudentNotFoundException() {
		super("student not available...");
	}
}
