package day4.layered;

import java.io.Serializable;

public class Student implements Serializable{
	private int regno;
	private String name;
	private String branch;
	private int total;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public Student(int regno, String name, String branch, int total) {
		this.regno = regno;
		this.name = name;
		this.branch = branch;
		this.total = total;
	}
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
}
