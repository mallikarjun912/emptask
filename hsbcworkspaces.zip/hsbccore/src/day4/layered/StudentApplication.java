package day4.layered;

import java.util.Scanner;

public class StudentApplication {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentService service = new StudentServiceImpl();
		StudentService streams = new StudentServiceImplStreams();
		int choice=0;
		while(choice!=4) {
			System.out.println("1 -- Add student ");
			System.out.println("2 -- Display all students");
			System.out.println("3 -- search for a student ");
			System.out.println("4 -- exit ");
			System.out.println("Enter your choice  ");
			choice = sc.nextInt();
			switch(choice) {
			case 1:{
				System.out.println("enter regno name branch total");
				int rno = sc.nextInt();
				String name = sc.next();
				String branch = sc.next();
				int total = sc.nextInt();
				Student std = new Student(rno, name, branch, total);
				//System.out.println(service.addStudent(std));
				System.out.println(streams.addStudent(std));
				break;
				}
			case 2:{
				//Student[] std = service.displayAllStudents();
					Student[] std = streams.displayAllStudents();
				for(Student s : std) 
					if(s!=null)
					System.out.println(s.getRegno()+s.getName()); 
				break;
			}
			case 3:{
						System.out.println("enter regno to search");
						int regno = sc.nextInt();
						try {
							//Student s = service.searchForStudent(regno);
							Student s = streams.searchForStudent(regno);
							System.out.println(s.getRegno()+s.getName());
						}
						catch(StudentNotFoundException e) { 
							System.out.println(e.getMessage());
							//e.printStackTrace();
						}
				}
			}
			
		}
		System.out.println("student application ends!!!");
	}
}
