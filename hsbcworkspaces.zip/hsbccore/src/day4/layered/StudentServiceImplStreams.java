package day4.layered;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class StudentServiceImplStreams implements StudentService{
	String file="d:\\hsbc23\\stdarray.dat";
	Student[] students = new Student[30]; 
	@Override
	public String addStudent(Student student) {
		String msg="inserted";
		try (	FileOutputStream fos = new FileOutputStream(file);
				ObjectOutputStream oos = new ObjectOutputStream(fos);)
			{	
				 oos.writeObject(students);
		} catch (IOException e) {
			
		}
		
		return msg;
	}

	@Override
	public Student searchForStudent(int regno) throws StudentNotFoundException {
		Student student=null;
		boolean found=false;
		try (
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);)
				{
				Object obj;
				while((obj=ois.readObject()) != null) {
					   student = (Student) obj;
					  if(student.getRegno()==regno) {
						  found = true;
						  break;
					  }
				}
			} catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		if(!found)
			throw new StudentNotFoundException(); 
		return student;
	}

	@Override
	public Student[] displayAllStudents() {
		//Student[] std = new Student[3]; 
		int size=0;
		try (
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);)
			{
			Object obj;
			while((obj=ois.readObject()) != null) {
				  Student std = (Student) obj;
				  students[size] = std;
				  size++;
			}
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		return students;
	

	}

}
