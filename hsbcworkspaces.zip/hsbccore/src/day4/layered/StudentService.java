package day4.layered;

public interface StudentService {  
	String addStudent(Student student);
	Student searchForStudent(int regno) throws StudentNotFoundException;
	Student[] displayAllStudents();
} 
