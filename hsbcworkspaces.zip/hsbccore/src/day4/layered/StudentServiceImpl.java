package day4.layered;


public class StudentServiceImpl implements StudentService{
	int size=0;
	Student[] students = new Student[3];
	@Override
	public String addStudent(Student student) {
		String msg="";
		students[size] = student;
		size++;
		return msg;
	}
	@Override
	public Student searchForStudent(int regno) throws StudentNotFoundException {
		Student std=null;
			boolean found=false;
			for(int i=0;i<size;i++) {
				if(students[i].getRegno() == regno) {
					found=true;  
					//return students[i];
					std = students[i];
					break;
				}
			}
			if(!found)
				throw new StudentNotFoundException(); 
			return std;
	}
	@Override
	public Student[] displayAllStudents() {
		return students;
	}
}
