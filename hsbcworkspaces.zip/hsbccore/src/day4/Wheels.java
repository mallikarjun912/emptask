package day4;

public interface Wheels {
	void rotate();
}
