package day4;

public class Mrf implements Wheels{
	@Override
	public void rotate() {
		System.out.println("Car is moving with MRF wheels"); 
	}
}
