package day8;

import java.util.TreeSet;

import day7.Employee;

public class EmployeeTreeSet {
	public static void main(String[] args) {
		TreeSet<Employee> empset = new TreeSet<>(new EmployeeSortByName());
		empset.add(new Employee(301,"hsbc")); 
		empset.add(new Employee(202,"james gosling"));
		empset.add(new Employee(303,"aasbc"));
		for(Employee e : empset)
			System.out.println(e.getCode()+" "+e.getName()+" "+e.hashCode()); 
	}
}
