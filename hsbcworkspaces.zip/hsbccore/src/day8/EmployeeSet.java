package day8;

import java.util.HashSet;
import day7.Employee;

public class EmployeeSet {
	public static void main(String[] args) {
		HashSet<Employee> empset = new HashSet<>();
		empset.add(new Employee(101,"hsbc")); 
		empset.add(new Employee(202,"james gosling"));
		empset.add(new Employee(101,"hsbc"));
		for(Employee e : empset)
			System.out.println(e.getCode()+" "+e.getName()+
					" "+e.hashCode()); 
	}
}
