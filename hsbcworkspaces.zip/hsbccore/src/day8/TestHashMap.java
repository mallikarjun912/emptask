package day8;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import day7.Employee;

public class TestHashMap {
	public static void main(String[] args) {
		HashMap<Integer, String> pb = new HashMap<>();
		pb.put(1234, "hsbc");
		pb.put(456, "james");
		pb.put(1234, "abcd");
		pb.put(789, "hsbc");
		pb.put(123, "hsbc");
		System.out.println(pb); 
		System.out.println(pb.get(123)); 
		Set<Entry<Integer, String>> set = pb.entrySet();
		Iterator<Entry<Integer, String>> itr = set.iterator();
		while(itr.hasNext()) {
			//System.out.println(itr.next());
			Map.Entry<Integer, String> entry = itr.next();
			System.out.println(entry.getKey()+" : "+entry.getValue()); 
		}
		HashMap<Integer, Employee> empls = new HashMap<>();
		empls.put(101, new Employee(101, "hsbc"));
		empls.put(102, new Employee(102, "james"));
		System.out.println(empls.get(101));  
		Set<Entry<Integer, Employee>> empset = empls.entrySet();
		Iterator<Entry<Integer, Employee>> itr2 = empset.iterator();
		while(itr2.hasNext()) {
			//Employee e = (Employee) itr2.next();
			System.out.println(itr2.next());
		//	System.out.println(e.getCode()+" "+e.getName());  
		}
		for(Entry<Integer, Employee> emp : empset) {
			System.out.println(emp.getKey()+" "+emp.getValue().getCode()); 
			//System.out.println(emp.getKey()+" "+emp.getValue()); 
		}
	}
}
