package day8;

import java.util.HashSet;
import java.util.Iterator;

public class TestHashSet {
	public static void main(String[] args) {
	HashSet<String> data = new HashSet<>();
	data.add("hsbc");
	data.add("678");
	data.add("hyd");
	data.add("hsbc");
	data.add(null);
	data.add("james");
	System.out.println(data);
	Iterator<String> itr = data.iterator();
	while(itr.hasNext())
		System.out.println(itr.next()); 
	}
}
