package day8;

import java.util.TreeSet;

public class TestTreeSet {
	public static void main(String[] args) {
		TreeSet<String> data = new TreeSet<>();
		data.add("hsbc");
		data.add("678");
		data.add("hyd");
		data.add("hsbc");
		data.add("james");
		System.out.println(data); 
	}
}
