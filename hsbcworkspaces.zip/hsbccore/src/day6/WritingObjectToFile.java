package day6;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WritingObjectToFile {
	public static void main(String[] args) {
		try {
			FileOutputStream fos = new FileOutputStream("d:\\hsbc23\\cardinfo");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			CardInfo card1 = new CardInfo(12345667899L, "HSBC",345,"10/25");
			CardInfo card2 = new CardInfo(98765432136L, "James",678,"11/30");
			oos.writeObject(card1);
			oos.writeObject(card2);
			oos.close();
			fos.close();
			System.out.println("created");
		} catch (IOException e) {
			e.printStackTrace(); 
		} 
	}
}
