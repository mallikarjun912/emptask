package day6;

import java.io.FileOutputStream;
import java.io.IOException;

public class WritingToFile {
	public static void main(String[] args) {
		try {
			FileOutputStream fos = new FileOutputStream("d:\\hsbc23\\sample.txt");
			for(int i=65;i<=91;i++)
				fos.write(i);
			fos.close();
			System.out.println("created");
		} catch (IOException e) { 
			e.printStackTrace();
		} 
	}
}
