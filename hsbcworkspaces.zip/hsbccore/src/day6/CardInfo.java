package day6;

import java.io.Serializable;

public class CardInfo implements Serializable{ 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long cardno;
	private String name;
	private int cvv;
	private String expiryDate;
	public CardInfo() {
		// TODO Auto-generated constructor stub
	}
	public CardInfo(long cardno, String name, int cvv, String expiryDate) {
		this.cardno = cardno;
		this.name = name;
		this.cvv = cvv;
		this.expiryDate = expiryDate;
	}
	public long getCardno() {
		return cardno;
	}
	public void setCardno(long cardno) {
		this.cardno = cardno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return "CardInfo [cardno=" + cardno + ", name=" + name + ", cvv=" + cvv + ", expiryDate=" + expiryDate + "]";
	}
	
}
