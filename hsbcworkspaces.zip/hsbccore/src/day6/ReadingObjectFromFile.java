package day6;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadingObjectFromFile {
	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream("d:\\hsbc23\\cardinfo");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Object obj;
			while((obj=ois.readObject()) != null) {
				CardInfo info = (CardInfo) obj;
				System.out.println(info); 
			}
			ois.close();
			fis.close();
		} catch (IOException | ClassNotFoundException e) {
				//e.printStackTrace(); 
		}
		
	}

}
