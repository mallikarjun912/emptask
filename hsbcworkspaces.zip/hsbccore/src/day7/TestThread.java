package day7;

public class TestThread {
	public static void main(String[] args) {
		Numbers num = new Numbers();
		Thread t1 =new Thread(num);
		Thread t2 = new Thread(num);
		Thread t3 = new Thread(num);
		t1.setName("A");
		t2.setName("B");
		t3.setName("C"); 
		t1.start();
		t2.start();
		t3.start();
	}
}
