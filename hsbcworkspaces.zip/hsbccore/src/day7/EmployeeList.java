package day7;

import java.util.ArrayList;
import java.util.Collections;

import day8.EmployeeSortByName;

public class EmployeeList {
	public static void main(String[] args) {
		ArrayList<Employee> emplist = new ArrayList<>();
		emplist.add(new Employee(101, "hsbc")); 
		emplist.add(new Employee(202, "james gosling"));
		emplist.add(new Employee(103,"rod johnson"));
		 System.out.println(emplist.contains(new Employee(101,"hsbc")));
 		
		
		Collections.sort(emplist, new EmployeeSortByName()); 
		for(Employee emp : emplist)
			System.out.println(emp.getCode()+" "+emp.getName());
	}
}
