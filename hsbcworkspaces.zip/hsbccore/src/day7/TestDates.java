package day7;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class TestDates {
	public static void main(String[] args) throws ParseException {
		Date date = new Date();
		System.out.println("default date = "+date);
		//convert date to string
		SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
		String dt = formater.format(date);
		System.out.println(dt); 
		//convert string to date
		String str = "15-08-2023";
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date d = sdf.parse(str);
		System.out.println(d);
		//convert to string to LocalDate
		String str2 = "2023-08-15";
		LocalDate local = LocalDate.parse(str2,DateTimeFormatter.ISO_DATE);
		System.out.println(local);  
		//convert to string to LocalDate
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate local2 = LocalDate.parse(str,dtf);
		System.out.println(local2);  
	}

}
