package day7;

import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayList {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add(50);
		list.add("hsbc");
		list.add('K');
		list.add(null);
		list.add(50);
		System.out.println(list+" "+list.size());    
		list.add("hyd");
		list.add(78);
		list.add(2, "java"); 
		System.out.println(list+" "+list.size());
		list.remove("hyd");
		list.remove(Integer.valueOf(50));
		System.out.println(list+" "+list.size());
		Iterator itr = list.listIterator();
		while(itr.hasNext()) {
			Object obj = itr.next();
			if(obj instanceof Integer)
			System.out.println(obj); 
		}
	}
}
