package day7;

import java.util.LinkedList;

public class TestLinkedLIst {
	public static void main(String[] args) {
		LinkedList<Integer> items = new LinkedList<>();
		items.add(50);
		items.add(80);
		System.out.println(items); 
		items.addFirst(70);
		items.addLast(10); 
		System.out.println(items); 
	}
}
