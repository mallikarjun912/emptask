package day7;

import java.util.ArrayList;

public class TestArrayList2 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("hyd");
		list.add("abcd");
		list.add("hsbc");
		System.out.println(list);
		System.out.println(list.contains("abcd"));  
		for(String s : list)
			System.out.println(s);  
	}
}
