package day7;

public class SampleThread extends Thread{
	@Override
	public void run() {
		for(int i=1;i<=5;i++)
			System.out.print(i+" ");
	}
	public static void main(String[] args) {
		SampleThread s1= new SampleThread();
		SampleThread s2= new SampleThread();
		SampleThread s3= new SampleThread();
		s1.start();
		s2.start();
		s3.start();
	}
}
