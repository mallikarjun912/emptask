package day9;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.mysql.cj.jdbc.Driver;

public class GetData {
	public static void main(String[] args) throws SQLException {
		DriverManager.registerDriver(new Driver()); 
		String url = "jdbc:mysql://localhost:3306/hsbc23";
		Connection conn = DriverManager.getConnection(url,"root","root");
		System.out.println("connected"); 
		String qry = "select * from student";
		PreparedStatement pst = conn.prepareStatement(qry);
		ResultSet rs = pst.executeQuery();
		ResultSetMetaData meta = rs.getMetaData();
		for(int i=1;i<=meta.getColumnCount();i++)
			System.out.print(meta.getColumnName(i)+"  ");
		System.out.println("\n------------------------------");
		
		while(rs.next())
			System.out.println(rs.getInt(1)+" "+rs.getString("stdname")+" "+rs.getString(3));
	
		// to get single student
		String qry2 = "select * from student where regno=?";
		pst = conn.prepareStatement(qry2);
		pst.setInt(1, 1010);
		rs = pst.executeQuery();
		if(rs.next())
			System.out.println(rs.getInt(1)+" "+rs.getString("stdname")+" "+rs.getString(3));
		else
			System.out.println("record not found");
	}
}
