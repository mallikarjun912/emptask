package day9;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;

public class TestDB {
	public static void main(String[] args) throws SQLException {
		DriverManager.registerDriver(new Driver()); 
		String url = "jdbc:mysql://localhost:3306/hsbc23";
		Connection conn = DriverManager.getConnection(url,"root","root");
		System.out.println("connected"); 
		Statement st = conn.createStatement();
		String query = "insert into student values(202,'xyz','1999-10-29')";
		//int rows = st.executeUpdate(query);
		//System.out.println(rows);
		
		
		String qry2 = "insert into student values(?,?,?)";
		PreparedStatement pst = conn.prepareStatement(qry2);
		pst.setInt(1, 245);
		pst.setString(2, "Hsbc");
		pst.setString(3, "2022-05-19");
		int rows = pst.executeUpdate();
		System.out.println(rows); 
	}
}
