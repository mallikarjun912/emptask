package day5;

public class SampleException2 extends Exception{
	public SampleException2() {
		super("called when exception is rethrown");
	}
	public SampleException2(String str) {
		super(str);
	}
}
