package day5;

public class AccountNotFoundException extends RuntimeException{
	public AccountNotFoundException() {
		super("account not available");
	}
}
