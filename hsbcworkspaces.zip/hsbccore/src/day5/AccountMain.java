package day5;

import java.util.Scanner;

public class AccountMain {
	public static void main(String[] args) {
		int acno=101;
		double balance=5000;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter acno and amount to withdraw");
		int ac=sc.nextInt();
		double amount = sc.nextDouble();
		try {
			if(ac!=acno)
				throw new AccountNotFoundException();
			if(amount>balance)
				throw new InsufficientBalanceException("less balance");
			System.out.println(" balance after withdraw = "+(balance-amount));
		}
		catch(AccountNotFoundException | InsufficientBalanceException e) {
			System.out.println(e.getMessage()); 
		}
		System.out.println("completed");  
	}

}
