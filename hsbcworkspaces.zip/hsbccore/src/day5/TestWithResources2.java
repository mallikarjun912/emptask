package day5;

import java.util.Scanner;

public class TestWithResources2 {

	public static void main(String[] args) {
		 String input = "";
		 try(Scanner scanner = new Scanner(System.in)){
	            while (!input.equals("q")) {
	                System.out.print("Input: ");
	                input = scanner.nextLine();
	                System.out.println("Input was: " + input);
	            }
	        }
	}
}
