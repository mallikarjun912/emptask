package day5;

public class InsufficientBalanceException extends RuntimeException{
	public InsufficientBalanceException(String str) {
		super(str);
	}
}
