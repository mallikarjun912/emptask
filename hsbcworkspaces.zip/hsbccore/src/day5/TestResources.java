package day5;

import java.util.Scanner;

public class TestResources {
	public static void main(String[] args) {
		
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter regno and name");
			int rno = sc.nextInt();
			String name = sc.next();
			System.out.println(rno+"  "+name);
			System.out.println("after closing enter a name");
			String s = sc.next();
			System.out.println(s); 
	}

}
