package day5;

public class TestExeption {
	public static void main(String[] args)  {
		int x=7;
		int y=0;
		int acno=1010;
		int arr[] = {5,4,7,8,9};
		try {
			if(acno!=101)
				throw new SampleException();
			int r=x/y;
			System.out.println("result = "+r);
			System.out.println("element = "+arr[3]);  
		}
		catch(ArithmeticException | IndexOutOfBoundsException e) {
			//e.printStackTrace();
			//throw new SampleException2();
		}
		catch (SampleException e) {
			System.out.println("Acno is not 101 hence SampleException is raised");
			throw e;
		} 
		System.out.println("success");
	}
}
