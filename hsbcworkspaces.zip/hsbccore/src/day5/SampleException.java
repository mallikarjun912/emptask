package day5;

public class SampleException extends RuntimeException{
	public SampleException() {
		super("this is a sample custom exception");
	}
	public SampleException(String str) {
		super(str);
	}
}
